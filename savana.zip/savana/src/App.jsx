import './index.css';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function App() {
  const navigate = useNavigate();
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setShowScroll(window.scrollY > 300);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bg-gradient-to-br from-purple-100 via-white to-indigo-100 text-gray-800 font-sans scroll-smooth transition-all duration-300">
      {/* Navbar */}
      <header className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center animate-fade-in-down">
        <h1 className="text-2xl font-bold text-indigo-700">Savana</h1>
        <button
          onClick={() => navigate('/auth')}
          className="bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 transition"
        >
          Get Started
        </button>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-6 py-24 text-center animate-fade-in-up">
        <h2 className="text-5xl font-extrabold text-indigo-800 leading-tight mb-6">
          Your 24/7 AI Therapist & Life Coach
        </h2>
        <p className="text-xl text-gray-700 max-w-2xl mx-auto mb-8">
          Enjoy a free 10-minute session with Savana — she listens, remembers, and helps you grow emotionally, spiritually, and professionally.
        </p>
        <div className="flex justify-center gap-4 flex-wrap">
          <button
            onClick={() => navigate('/auth')}
            className="bg-indigo-600 text-white px-8 py-4 rounded-full text-lg hover:bg-indigo-700 transition"
          >
            🎤 Try Free Voice Session
          </button>
          <button
            onClick={() => navigate('/chat')}
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full text-lg hover:from-purple-700 hover:to-pink-700 transition"
          >
            💬 Start Chatting
          </button>
          <a
            href="#pricing"
            className="border border-indigo-600 text-indigo-700 px-8 py-4 rounded-full text-lg hover:bg-indigo-50 transition"
          >
            View Plans
          </a>
        </div>
      </section>

      {/* Demo Video */}
      <section id="demo" className="py-20 px-6 bg-white text-center animate-fade-in-up">
        <h3 className="text-2xl font-bold text-indigo-700 mb-6">See How Savana Works</h3>
        <p className="text-gray-700 mb-8">Watch a sample voice session where Savana helps someone in real time.</p>
        <div className="max-w-3xl mx-auto aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-lg">
          <iframe
            className="w-full h-80"
            src="https://www.youtube.com/embed/WEBJY8iUmYY?si=1s7pBtq57DQVKvDQ"
            title="Demo Session"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </section>

      {/* Features */}
      <section className="bg-indigo-50 py-20 px-6 animate-fade-in-up">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-indigo-700 mb-10">What Can Savana Help With?</h3>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            {[
              {
                title: "🧘 Life Coaching",
                text: "Get direction, overcome self-doubt, and build habits that transform your life.",
              },
              {
                title: "💼 Business Coaching",
                text: "Navigate business challenges with clarity, wisdom, and strategy.",
              },
              {
                title: "❤️ Couples Therapy",
                text: "Improve communication, heal pain, and grow closer as a couple.",
              },
              {
                title: "🕊️ Spiritual Guidance",
                text: "Go deeper into your purpose and align with your higher self.",
              },
              {
                title: "🌱 Personal Growth",
                text: "Set personal goals, understand yourself, and heal emotional wounds.",
              },
              {
                title: "🧠 Continuous Memory",
                text: "Savana remembers your sessions so you never have to start over.",
              },
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl shadow-md hover:scale-105 transform transition">
                <h4 className="text-xl font-semibold text-indigo-800 mb-2">{item.title}</h4>
                <p className="text-gray-700">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 px-6 bg-gradient-to-br from-indigo-50 to-purple-50 text-center animate-fade-in-up">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h3 className="text-5xl font-bold text-indigo-800 mb-6">Simple Pricing for Everyone</h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose the perfect plan for your journey to better mental health and personal growth.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: 'Starter',
                price: 'Free',
                desc: '1 trial voice session (10 mins)',
                features: ['10-minute trial', 'Basic AI coaching', 'No commitment'],
                popular: false
              },
              {
                title: 'Text Only',
                price: '$29.9/mo',
                desc: 'Unlimited chat with Savana\'s wisdom',
                features: ['Unlimited text chat', 'Memory retention', '24/7 availability'],
                popular: false
              },
              {
                title: 'Pro Voice',
                price: '$59.9/mo',
                desc: '10 voice calls + full chat',
                features: ['10 voice sessions/month', 'Unlimited text chat', 'Priority support', 'Advanced memory'],
                popular: true
              },
              {
                title: 'Enterprise',
                price: 'Custom',
                desc: 'Unlimited everything for teams or clinics',
                features: ['Unlimited everything', 'Team management', 'Custom integrations', 'Dedicated support'],
                popular: false
              },
            ].map((plan, i) => (
              <div key={i} className={`relative bg-white p-8 rounded-3xl shadow-lg text-left transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl ${plan.popular ? 'ring-4 ring-indigo-500 scale-105' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-bold">
                      Most Popular
                    </span>
                  </div>
                )}
                <div className="text-center mb-6">
                  <h4 className="text-2xl font-bold text-indigo-800 mb-2">{plan.title}</h4>
                  <div className="text-4xl font-black text-indigo-600 mb-2">{plan.price}</div>
                  <p className="text-gray-600 text-sm">{plan.desc}</p>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-green-600 text-xs">✓</span>
                      </div>
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => navigate('/auth')}
                  className={`w-full py-4 rounded-2xl font-semibold transition-all duration-300 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700'
                      : 'border-2 border-indigo-200 text-indigo-600 hover:bg-indigo-600 hover:text-white'
                  }`}
                >
                  {plan.title === 'Starter' ? 'Start Free Trial' : 'Select Plan'}
                </button>
              </div>
            ))}
          </div>
          <p className="text-gray-500 mt-12 text-lg">
            🚀 More flexible plans coming soon. Start with the free trial today and experience the difference.
          </p>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 animate-fade-in-up relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{backgroundImage: "url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%239C92AC%22 fill-opacity=%220.1%22%3E%3Ccircle cx=%227%22 cy=%227%22 r=%227%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')"}}></div>

        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="mb-16">
            <h3 className="text-5xl font-bold text-white mb-4">People Are Talking</h3>
            <p className="text-xl text-indigo-200">Real stories from people who found their voice with Savana</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "I feel like someone finally listens deeply to what I'm really saying.",
                name: "Jane M.",
                role: "Marketing Professional",
                rating: 5
              },
              {
                quote: "It's like having a therapist that evolves with you and remembers everything.",
                name: "Eli B.",
                role: "Software Engineer",
                rating: 5
              },
              {
                quote: "No app has ever understood me like this. It's genuinely life-changing.",
                name: "Amir T.",
                role: "Entrepreneur",
                rating: 5
              },
            ].map((t, i) => (
              <div key={i} className="bg-white/10 backdrop-blur-lg p-8 rounded-3xl border border-white/20 hover:bg-white/15 transition-all duration-300">
                <div className="flex mb-4">
                  {[...Array(t.rating)].map((_, j) => (
                    <span key={j} className="text-yellow-400 text-xl">★</span>
                  ))}
                </div>
                <p className="text-lg text-white mb-6 leading-relaxed">"{t.quote}"</p>
                <div className="text-left">
                  <div className="font-semibold text-white">{t.name}</div>
                  <div className="text-indigo-200 text-sm">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center py-10 text-gray-500 text-sm">
        &copy; {new Date().getFullYear()} Savana AI — Created with love to reduce suffering.
      </footer>

     {/*
      {showScroll && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-24 right-6 p-3 bg-indigo-600 text-white rounded-full shadow-lg hover:bg-indigo-700 transition z-50"
        >
          ↑
        </button>
      )}
     */}
    </div>
  );
}























