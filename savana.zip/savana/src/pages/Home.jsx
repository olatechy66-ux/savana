import { useState } from "react";

export default function Home() {
  const [isCalling, setIsCalling] = useState(false);
  const [transcript, setTranscript] = useState("");

  const startCall = async () => {
    setIsCalling(true);
    try {
      // Simulate Retell call (mocked)
      await new Promise((r) => setTimeout(r, 1000));
      setTranscript("Hi, I’m Savannah. What’s on your mind today?");
    } catch (err) {
      console.error(err);
    } finally {
      setIsCalling(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-50 p-4">
      <div className="bg-white/90 backdrop-blur-lg shadow-2xl rounded-3xl p-10 max-w-lg w-full space-y-8 border border-white/20">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-white font-bold text-2xl">S</span>
          </div>
          <h1 className="text-4xl font-black bg-gradient-to-r from-indigo-700 to-purple-600 bg-clip-text text-transparent mb-3">
            Welcome to Savana 🤍
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">Your AI therapist is here to listen, support, and guide you through life's journey.</p>
        </div>

        <button
          onClick={startCall}
          disabled={isCalling}
          className={`w-full px-8 py-4 rounded-2xl font-bold text-lg text-white transition-all duration-300 shadow-lg transform ${
            isCalling 
              ? "bg-gray-400 cursor-not-allowed" 
              : "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 hover:shadow-xl hover:-translate-y-1"
          }`}
        >
          {isCalling ? (
            <div className="flex items-center justify-center gap-3">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Connecting...
            </div>
          ) : (
            <div className="flex items-center justify-center gap-3">
              <span className="text-xl">🎤</span>
              Start Session
            </div>
          )}
        </button>

        {transcript && (
          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-2xl border border-indigo-100">
            <p className="font-bold text-indigo-700 mb-2">Transcript:</p>
            <p className="text-gray-700 text-lg leading-relaxed">{transcript}</p>
          </div>
        )}
      </div>
    </div>
  );
}