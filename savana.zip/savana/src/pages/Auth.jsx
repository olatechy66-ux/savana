import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useNavigate } from 'react-router-dom';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';

export default function Auth() {
  const [mode, setMode] = useState('signup'); // or 'login'
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState('form'); // form | verify
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSignup = async () => {
    setLoading(true);
    setError(null);

    try {
      console.log('Attempting signup with phone:', phone);

      const { error } = await supabase.auth.signUp({
        phone,
        password,
      });

      if (error) {
        console.error('Signup error:', error);
        setError(error.message);
      } else {
        console.log('Signup successful, moving to verify step');
        setStep('verify');
      }
    } catch (err) {
      console.error('Unexpected signup error:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
  setLoading(true);
  setError(null);

  try {
    console.log('Attempting to verify OTP:', otp, 'for phone:', phone);
    // Step 1: Verify the OTP
    const { error: verifyError } = await supabase.auth.verifyOtp({
      phone,
      token: otp,
      type: 'sms',
    });

    if (verifyError) {
      console.error('OTP verification error:', verifyError);
      setError(verifyError.message);
      setLoading(false);
      return;
    }

    console.log('OTP verification successful, proceeding to sign in');
    // ✅ Step 2: Sign in again to get session token
    const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
      phone,
      password,
    });

    if (signInError) {
      console.error('Sign in after OTP verification error:', signInError);
      setError(signInError.message);
      setLoading(false);
      return;
    }

    console.log('Sign in successful, upserting profile');
    // ✅ Step 3: Upsert into `profiles` with auth token now available
    const user = signInData.user;
    const { error: profileError } = await supabase.from('profiles').upsert({
      id: user.id,
      phone: phone,
    });

    if (profileError) {
      console.error('Profile upsert error:', profileError);
      setError(profileError.message);
      setLoading(false);
      return;
    }

    console.log('Profile upsert successful, navigating to dashboard');
    navigate('/dashboard');
  } catch (err) {
    console.error('Unexpected error during verification or login:', err);
    setError('An unexpected error occurred during verification. Please try again.');
  } finally {
    setLoading(false);
  }
};



  const handleLogin = async () => {
    setLoading(true);
    setError(null);

    try {
      console.log('Attempting login with phone:', phone);

      const { error } = await supabase.auth.signInWithPassword({
        phone,
        password,
      });

      if (error) {
        console.error('Login error:', error);
        setError(error.message);
      } else {
        console.log('Login successful, navigating to dashboard');
        navigate('/dashboard');
      }
    } catch (err) {
      console.error('Unexpected login error:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 to-teal-100">
      <div className="bg-white p-8 rounded-xl shadow-md max-w-sm w-full space-y-4">
        <h2 className="text-2xl font-bold text-center text-indigo-700">
          {mode === 'signup'
            ? step === 'verify'
              ? 'Verify Your Phone'
              : 'Sign Up'
            : 'Login'}
        </h2>

        {error && <p className="text-red-500 text-center">{error}</p>}

        {step === 'form' && (
          <>
            <PhoneInput
              placeholder="Enter phone number"
              value={phone}
              onChange={setPhone}
              defaultCountry="NG"
              className="w-full border rounded px-3 py-2"
              international
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 border rounded"
            />
            <button
              onClick={mode === 'signup' ? handleSignup : handleLogin}
              className="w-full bg-indigo-600 text-white p-3 rounded hover:bg-indigo-700"
              disabled={loading}
            >
              {loading
                ? 'Loading...'
                : mode === 'signup'
                ? 'Send OTP'
                : 'Log In'}
            </button>
          </>
        )}

        {step === 'verify' && (
          <>
            <input
              type="text"
              placeholder="Enter OTP code"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full p-3 border rounded"
            />
            <button
              onClick={handleVerify}
              className="w-full bg-indigo-600 text-white p-3 rounded hover:bg-indigo-700"
              disabled={loading}
            >
              {loading ? 'Verifying...' : 'Verify & Login'}
            </button>
          </>
        )}

        <p className="text-center text-sm text-gray-500">
          {mode === 'signup' ? 'Have an account?' : 'Need an account?'}{' '}
          <button
            className="underline"
            onClick={() => {
              setMode(mode === 'signup' ? 'login' : 'signup');
              setStep('form');
              setError(null);
            }}
          >
            {mode === 'signup' ? 'Login' : 'Sign up'}
          </button>
        </p>
      </div>
    </div>
  );
}